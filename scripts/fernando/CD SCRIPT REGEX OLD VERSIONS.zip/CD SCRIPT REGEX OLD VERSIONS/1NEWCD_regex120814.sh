#!/bin/sh
#Este script para etiquetado de intervenciones de los diputados del CD
#autores: fg, mc
#fecha: 12/08/2014
#ETIQUETADO CON XML 
#(al convertir los discursos en pdf es más cómodo etiquetarlos en XML que en HTML, por las etiquetas que usa el conversor, en este caso ADOBE ACROBAT X PRO)
#perl -pi -e 's///g' *.xml



##PARTE 1 
##PORTADA, ORDEN DEL DÍA Y SUMARIO

# 1 dejarlo todo en una línea
perl -pi -e 's/(\n|\r)+//g' *.xml

# Datos portada
perl -pi -e 's/<\?xml version.*?(CORTES GENERALES)/XXZZ?xml version="1.0" encoding="UTF-8" standalone="no"?YYWWXXZZPYYWWXXZZ!DOCTYPE ecpc_CD SYSTEM "cd.dtd"YYWWXXZZPYYWWXXZZecpc_CDYYWWXXZZPYYWW$1/g' *.xml

#datos portada 2
perl -pi -e 's/(CORTES GENERALES)(.*?Núm.*?)<\/P>.*?<P>(Sesión.*?)<\/P>.*?(celebrada.*?)<P>.*?(ORDEN DEL DÍA:)/XXZZtitleYYWW$2$4XXZZ\/titleYYWWXXZZPYYWWXXZZlabelYYWW$3XXZZ\/labelYYWWXXZZPYYWWXXZZdateYYWW$4XXZZ\/dateYYWWXXZZPYYWWXXZZplaceYYWW$1XXZZ\/placeYYWWXXZZPYYWWXXZZeditionYYWW$2XXZZ\/editionYYWWXXZZPYYWWXXZZindexYYWWXXZZPYYWWXXZZindexitemYYWWXXZZPYYWW$5XXZZPYYWW/g' *.xml

#headings 1
perl -pi -e 's/([^\p{Lu}]\.\s*?<\/P>|[^\p{Lu}]\.\)\s*?<\/P>)(<P>|<H4>)(—|)(\s*?\p{Lu}\p{Lu}+?\s*?\p{Lu}\p{Lu}+?\s*?\p{Lu}\p{Lu}.*?\(Número de expediente.*?\))/$1XXZZPYYWWXXZZheadingYYWWXXZZPYYWW$4XXZZPYYWWXXZZ\/headingYYWWXXZZPYYWW/g' *.xml

#orden del día
perl -pi -e 's/(ORDEN DEL DÍA:XXZZPYYWW)(.*?)(SUMARIO)/$1$2XXZZ\/indexitemYYWWXXZZPYYWWXXZZindexitemYYWWXXZZPYYWW$3:/g' *.xml

# sumario con vicepresidente/a
perl -pi -e 's/(SUMARIO)(.*?)(XXZZPYYWWXXZZheadingYYWWXXZZPYYWW)(\s*?\p{Lu}\p{Lu}+?.*?)(<P>El señor VICEPRESIDENTE\s*?\(\p{Lu}\p{Ll}.+?\p{Ll}\):|<P>La señora VICEPRESIDENTA\s*?\(\p{Lu}\p{Ll}.+?\p{Ll}\):)/$1$2XXZZPYYWWXXZZ\/indexitemYYWWXXZZPYYWWXXZZ\/indexYYWWXXZZPYYWWXXZZ\/headerYYWWXXZZPYYWWXXZZPYYWWXXZZbodyYYWWXXZZPYYWWXXZZchair_whoYYWWXXZZPYYWW$3$4$5/g' *.xml

#sumario con presidente/a
perl -pi -e 's/(SUMARIO)(.*?)(XXZZPYYWWXXZZheadingYYWWXXZZPYYWW)(\s*?\p{Lu}\p{Lu}+?.*?)(<P>El señor PRESIDENTE\s*?\(\p{Lu}\p{Ll}.+?\p{Ll}\):|<P>La señora PRESIDENTA\s*?\(\p{Lu}\p{Ll}.+?\p{Ll}\):)/$1$2XXZZPYYWWXXZZ\/indexitemYYWWXXZZPYYWWXXZZ\/indexYYWWXXZZPYYWWXXZZ\/headerYYWWXXZZPYYWWXXZZPYYWWXXZZbodyYYWWXXZZPYYWWXXZZchair_whoYYWWXXZZPYYWW$3$4$5/g' *.xml


##PARTE 2
##INTERVENCIONES

# hacer distincion donde empieza una intervencion señalando que es un parrafo diferente 1 ¿PASAR ESTE DOS VECES?
perl -pi -e 's/(<P>|<H4>)(El señor\s*?\p{Lu}\p{Lu}+?.*?)(\(\p{Lu}\p{Ll}+?.*?\p{Ll}\p{Ll}\)\s*?:)/<PARRAFO_2>$2$3/g' *.xml

perl -pi -e 's/(<P>|<H4>)(El señor\s*?\p{Lu}\p{Lu}+?.*?)(\(\p{Lu}\p{Ll}+?.*?\p{Ll}\p{Ll}\)\s*?:)/<PARRAFO_2>$2$3/g' *.xml

perl -pi -e 's/(<P>|<H4>)(El señor\s*?\p{Lu}\p{Lu}+?.*?)(\p{Lu}\p{Lu}+?.*?\p{Lu}\p{Lu}\s*?:)/<PARRAFO_2>$2$3/g' *.xml

perl -pi -e 's/(<P>|<H4>)(El señor\s*?\p{Lu}\p{Lu}+?.*?)(\p{Lu}\p{Lu}+?.*?\p{Lu}\p{Lu}\s*?:)/<PARRAFO_2>$2$3/g' *.xml

# hacer distincion donde empieza una intervencion señalando que es un parrafo diferente 2
perl -pi -e 's/(<P>|<H4>)(La señora\s*?\p{Lu}\p{Lu}+?.*?)(\(\p{Lu}\p{Ll}+?.*?\p{Ll}\p{Ll}\)\s*?:)/<PARRAFO_2>$2$3/g' *.xml

perl -pi -e 's/(<P>|<H4>)(La señora\s*?\p{Lu}\p{Lu}+?.*?)(\(\p{Lu}\p{Ll}+?.*?\p{Ll}\p{Ll}\)\s*?:)/<PARRAFO_2>$2$3/g' *.xml

perl -pi -e 's/(<P>|<H4>)(La señora\s*?\p{Lu}\p{Lu}+?.*?)(\p{Lu}\p{Lu}+?.*?\p{Lu}\p{Lu}\s*?:)/<PARRAFO_2>$2$3/g' *.xml

perl -pi -e 's/(<P>|<H4>)(La señora\s*?\p{Lu}\p{Lu}+?.*?)(\p{Lu}\p{Lu}+?.*?\p{Lu}\p{Lu}\s*?:)/<PARRAFO_2>$2$3/g' *.xml

# intervenciones PRESIDENTe/a: (del congreso) 1
perl -pi -e 's/(<PARRAFO_2>)El señor\s*?(PRESIDENTE)\s*?:(.*?)(<PARRAFO_2>)/$1XXZZPYYWWXXZZinterventionYYWWXXZZPYYWWXXZZspeakerYYWWXXZZPYYWWXXZZnameYYWWMARÍN GONZÁLEZXXZZ\/nameYYWWXXZZPYYWWXXZZbirth_dateYYWWXXZZ\/birth_dateYYWWXXZZPYYWWXXZZstatusYYWWXXZZ\/statusYYWWXXZZPYYWWXXZZgenderYYWWXXZZ\/genderYYWWXXZZPYYWWXXZZinstitutionYYWWXXZZPYYWWXXZZniYYWWXXZZ\/niYYWWXXZZPYYWWXXZZ\/institutionYYWWXXZZPYYWWXXZZconstituencyYYWWXXZZ\/constituencyYYWWXXZZPYYWWXXZZaffiliationYYWWXXZZPYYWWXXZZnational_partyYYWWXXZZ\/national_partyYYWWXXZZPYYWWXXZZcdYYWWXXZZ\/cdYYWWXXZZPYYWWXXZZ\/affiliationYYWWXXZZPYYWWXXZZpostYYWW$2XXZZ\/postYYWWXXZZPYYWWXXZZ\/speakerYYWWXXZZPYYWWXXZZspeechYYWWXXZZPYYWW$3XXZZPYYWWXXZZ\/speechYYWWXXZZPYYWWXXZZ\/interventionYYWWXXZZPYYWW$4/g' *.xml

# intervenciones PRESIDENTe/a: (del congreso) 2
perl -pi -e 's/(<PARRAFO_2>)La señora\s*?(PRESIDENTA)\s*?:(.*?)(<PARRAFO_2>)/$1XXZZPYYWWXXZZinterventionYYWWXXZZPYYWWXXZZspeakerYYWWXXZZPYYWWXXZZnameYYWWMARÍN GONZÁLEZXXZZ\/nameYYWWXXZZPYYWWXXZZbirth_dateYYWWXXZZ\/birth_dateYYWWXXZZPYYWWXXZZstatusYYWWXXZZ\/statusYYWWXXZZPYYWWXXZZgenderYYWWXXZZ\/genderYYWWXXZZPYYWWXXZZinstitutionYYWWXXZZPYYWWXXZZniYYWWXXZZ\/niYYWWXXZZPYYWWXXZZ\/institutionYYWWXXZZPYYWWXXZZconstituencyYYWWXXZZ\/constituencyYYWWXXZZPYYWWXXZZaffiliationYYWWXXZZPYYWWXXZZnational_partyYYWWXXZZ\/national_partyYYWWXXZZPYYWWXXZZcdYYWWXXZZ\/cdYYWWXXZZPYYWWXXZZ\/affiliationYYWWXXZZPYYWWXXZZpostYYWW$2XXZZ\/postYYWWXXZZPYYWWXXZZ\/speakerYYWWXXZZPYYWWXXZZspeechYYWWXXZZPYYWW$3XXZZPYYWWXXZZ\/speechYYWWXXZZPYYWWXXZZ\/interventionYYWWXXZZPYYWW$4/g' *.xml

#intervencion vicepres 1
perl -pi -e 's/(<PARRAFO_2>)El señor\s*?(PRESIDENTE|VICEPRESIDENTE|PRESIDENTE DEL GOBIERNO)\s*?\((\p{Lu}\p{Ll}.+?\p{Ll})\):(.*?)(<PARRAFO_2>)/$1XXZZPYYWWXXZZinterventionYYWWXXZZPYYWWXXZZspeakerYYWWXXZZPYYWWXXZZnameYYWW$3XXZZ\/nameYYWWXXZZPYYWWXXZZbirth_dateYYWWXXZZ\/birth_dateYYWWXXZZPYYWWXXZZstatusYYWWXXZZ\/statusYYWWXXZZPYYWWXXZZgenderYYWWXXZZ\/genderYYWWXXZZPYYWWXXZZinstitutionYYWWXXZZPYYWWXXZZniYYWWXXZZ\/niYYWWXXZZPYYWWXXZZ\/institutionYYWWXXZZPYYWWXXZZconstituencyYYWWXXZZ\/constituencyYYWWXXZZPYYWWXXZZaffiliationYYWWXXZZPYYWWXXZZnational_partyYYWWXXZZ\/national_partyYYWWXXZZPYYWWXXZZcdYYWWXXZZ\/cdYYWWXXZZPYYWWXXZZ\/affiliationYYWWXXZZPYYWWXXZZpostYYWW$2XXZZ\/postYYWWXXZZPYYWWXXZZ\/speakerYYWWXXZZPYYWWXXZZspeechYYWWXXZZPYYWW$4XXZZPYYWWXXZZ\/speechYYWWXXZZPYYWWXXZZ\/interventionYYWWXXZZPYYWW$5/g' *.xml

# intervencion vicepres 2
perl -pi -e 's/(<PARRAFO_2>)La señora\s*?(PRESIDENTA|VICEPRESIDENTA|PRESIDENTA DEL GOBIERNO)\s*?\((\p{Lu}\p{Ll}.+?\p{Ll})\):(.*?)(<PARRAFO_2>)/$1XXZZPYYWWXXZZinterventionYYWWXXZZPYYWWXXZZspeakerYYWWXXZZPYYWWXXZZnameYYWW$3XXZZ\/nameYYWWXXZZPYYWWXXZZbirth_dateYYWWXXZZ\/birth_dateYYWWXXZZPYYWWXXZZstatusYYWWXXZZ\/statusYYWWXXZZPYYWWXXZZgenderYYWWXXZZ\/genderYYWWXXZZPYYWWXXZZinstitutionYYWWXXZZPYYWWXXZZniYYWWXXZZ\/niYYWWXXZZPYYWWXXZZ\/institutionYYWWXXZZPYYWWXXZZconstituencyYYWWXXZZ\/constituencyYYWWXXZZPYYWWXXZZaffiliationYYWWXXZZPYYWWXXZZnational_partyYYWWXXZZ\/national_partyYYWWXXZZPYYWWXXZZcdYYWWXXZZ\/cdYYWWXXZZPYYWWXXZZ\/affiliationYYWWXXZZPYYWWXXZZpostYYWW$2XXZZ\/postYYWWXXZZPYYWWXXZZ\/speakerYYWWXXZZPYYWWXXZZspeechYYWWXXZZPYYWW$4XXZZPYYWWXXZZ\/speechYYWWXXZZPYYWWXXZZ\/interventionYYWWXXZZPYYWW$5/g' *.xml

#intervenciones ministros CARGO EN MAYUSCULS Y ORADOR EN MINUSCULAS Y PARENTESIS 1
perl -pi -e 's/(<PARRAFO_2>)El señor (MINISTR\p{Lu}.*?\p{Lu}\p{Lu})\s*?\((\p{Lu}\p{Ll}.+?\p{Ll})\):(.*?)(<PARRAFO_2>)/$1XXZZPYYWWXXZZinterventionYYWWXXZZPYYWWXXZZspeakerYYWWXXZZPYYWWXXZZnameYYWW$3XXZZ\/nameYYWWXXZZPYYWWXXZZbirth_dateYYWWXXZZ\/birth_dateYYWWXXZZPYYWWXXZZstatusYYWWXXZZ\/statusYYWWXXZZPYYWWXXZZgenderYYWWXXZZ\/genderYYWWXXZZPYYWWXXZZinstitutionYYWWXXZZPYYWWXXZZniYYWWXXZZ\/niYYWWXXZZPYYWWXXZZ\/institutionYYWWXXZZPYYWWXXZZconstituencyYYWWXXZZ\/constituencyYYWWXXZZPYYWWXXZZaffiliationYYWWXXZZPYYWWXXZZnational_partyYYWWXXZZ\/national_partyYYWWXXZZPYYWWXXZZcdYYWWXXZZ\/cdYYWWXXZZPYYWWXXZZ\/affiliationYYWWXXZZPYYWWXXZZpostYYWW$2XXZZ\/postYYWWXXZZPYYWWXXZZ\/speakerYYWWXXZZPYYWWXXZZspeechYYWWXXZZPYYWW$4XXZZPYYWWXXZZ\/speechYYWWXXZZPYYWWXXZZ\/interventionYYWWXXZZPYYWW$5/g' *.xml

#intervenciones ministros CARGO EN MAYUSCULS Y ORADOR EN MINUSCULAS Y PARENTESIS 2
perl -pi -e 's/(<PARRAFO_2>)La señora (MINISTR\p{Lu}.*?\p{Lu}\p{Lu})\s*?\((\p{Lu}\p{Ll}.+?\p{Ll})\):(.*?)(<PARRAFO_2>)/$1XXZZPYYWWXXZZinterventionYYWWXXZZPYYWWXXZZspeakerYYWWXXZZPYYWWXXZZnameYYWW$3XXZZ\/nameYYWWXXZZPYYWWXXZZbirth_dateYYWWXXZZ\/birth_dateYYWWXXZZPYYWWXXZZstatusYYWWXXZZ\/statusYYWWXXZZPYYWWXXZZgenderYYWWXXZZ\/genderYYWWXXZZPYYWWXXZZinstitutionYYWWXXZZPYYWWXXZZniYYWWXXZZ\/niYYWWXXZZPYYWWXXZZ\/institutionYYWWXXZZPYYWWXXZZconstituencyYYWWXXZZ\/constituencyYYWWXXZZPYYWWXXZZaffiliationYYWWXXZZPYYWWXXZZnational_partyYYWWXXZZ\/national_partyYYWWXXZZPYYWWXXZZcdYYWWXXZZ\/cdYYWWXXZZPYYWWXXZZ\/affiliationYYWWXXZZPYYWWXXZZpostYYWW$2XXZZ\/postYYWWXXZZPYYWWXXZZ\/speakerYYWWXXZZPYYWWXXZZspeechYYWWXXZZPYYWW$4XXZZPYYWWXXZZ\/speechYYWWXXZZPYYWWXXZZ\/interventionYYWWXXZZPYYWW$5/g' *.xml

#intervenciones normales, dos apellidos en mayusc y :  1
perl -pi -e 's/(<PARRAFO_2>)El señor\s*?(\p{Lu}\p{Lu}+?.*?\p{Lu}\p{Lu})\s*?:(.*?)(<PARRAFO_2>)/$1XXZZPYYWWXXZZinterventionYYWWXXZZPYYWWXXZZspeakerYYWWXXZZPYYWWXXZZnameYYWW$2XXZZ\/nameYYWWXXZZPYYWWXXZZbirth_dateYYWWXXZZ\/birth_dateYYWWXXZZPYYWWXXZZstatusYYWWXXZZ\/statusYYWWXXZZPYYWWXXZZgenderYYWWXXZZ\/genderYYWWXXZZPYYWWXXZZinstitutionYYWWXXZZPYYWWXXZZniYYWWXXZZ\/niYYWWXXZZPYYWWXXZZ\/institutionYYWWXXZZPYYWWXXZZconstituencyYYWWXXZZ\/constituencyYYWWXXZZPYYWWXXZZaffiliationYYWWXXZZPYYWWXXZZnational_partyYYWWXXZZ\/national_partyYYWWXXZZPYYWWXXZZcdYYWWXXZZ\/cdYYWWXXZZPYYWWXXZZ\/affiliationYYWWXXZZPYYWWXXZZpostYYWWN\/AXXZZ\/postYYWWXXZZPYYWWXXZZ\/speakerYYWWXXZZPYYWWXXZZspeechYYWWXXZZPYYWW$3XXZZPYYWWXXZZ\/speechYYWWXXZZPYYWWXXZZ\/interventionYYWWXXZZPYYWW$4/g' *.xml

#intervenciones normales, dos apellidos en mayusc y :  2
perl -pi -e 's/(<PARRAFO_2>)La señora\s*?(\p{Lu}\p{Lu}+?.*?\p{Lu}\p{Lu})\s*?:(.*?)(<PARRAFO_2>)/$1XXZZPYYWWXXZZinterventionYYWWXXZZPYYWWXXZZspeakerYYWWXXZZPYYWWXXZZnameYYWW$2XXZZ\/nameYYWWXXZZPYYWWXXZZbirth_dateYYWWXXZZ\/birth_dateYYWWXXZZPYYWWXXZZstatusYYWWXXZZ\/statusYYWWXXZZPYYWWXXZZgenderYYWWXXZZ\/genderYYWWXXZZPYYWWXXZZinstitutionYYWWXXZZPYYWWXXZZniYYWWXXZZ\/niYYWWXXZZPYYWWXXZZ\/institutionYYWWXXZZPYYWWXXZZconstituencyYYWWXXZZ\/constituencyYYWWXXZZPYYWWXXZZaffiliationYYWWXXZZPYYWWXXZZnational_partyYYWWXXZZ\/national_partyYYWWXXZZPYYWWXXZZcdYYWWXXZZ\/cdYYWWXXZZPYYWWXXZZ\/affiliationYYWWXXZZPYYWWXXZZpostYYWWN\/AXXZZ\/postYYWWXXZZPYYWWXXZZ\/speakerYYWWXXZZPYYWWXXZZspeechYYWWXXZZPYYWW$3XXZZPYYWWXXZZ\/speechYYWWXXZZPYYWWXXZZ\/interventionYYWWXXZZPYYWW$4/g' *.xml

#cierre body back y ecpc_CD al final del documento
perl -pi -e 's/(>)(Edita:.*?Depósito legal:.*?<\/P>)(.*?\Z)/$1$3XXZZPYYWWXXZZ\/chairYYWWXXZZPYYWWXXZZPYYWWXXZZ\/bodyYYWWXXZZPYYWWXXZZPYYWWXXZZbackYYWW$2XXZZ\/backYYWWXXZZPYYWWXXZZ\/ecpc_CDYYWW/g' *.xml

# omitir
perl -pi -e 's/\(Aplausos.\)/XXZZomitYYWW\(Aplausos.\)XXZZ\/omitYYWW/g' *.xml

# omitir
perl -pi -e 's/\(Rumores.\)/XXZZomitYYWW\(Rumores.\)XXZZ\/omitYYWW/g' *.xml

# omitir
perl -pi -e 's/\(Risas.\)/XXZZomitYYWW\(Risas.\)XXZZ\/omitYYWW/g' *.xml

# párrafos
perl -pi -e 's/<P>/XXZZPYYWW/g' *.xml

#párrafo
perl -pi -e 's/XXZZPYYWW/\n/g' *.xml

# quitar las etiquetas que queden 1
perl -pi -e 's/<.*?>//g' *.xml

# transformar nuestras etiquetas

perl -pi -e 's/XXZZ/</g' *.xml

perl -pi -e 's/YYWW/>/g' *.xml


##Falta por etiquetar:

##PARTE 1

#<header filename='CD20050111' language="ES">
#<legislature begin="20040402" end="20080401">VIII</legislature>

#<chair who="Marín González, Manuel">
#<omit>PRESIDENCIA DEL EXCMO. SR. D. MANUEL MARÍN GONZÁLEZ</omit>


##PARTE 2

##FALTA COMPLETAR DATOS ORADORES CON SCRIPT QUE DIRIJA A DATOS DIPUTADOS

##PROBLEMA: EL NOMBRE DEL/LA PRESIDENTE/A del CD SE DEBE PONER "A MANO" PARA CADA LEGISLATURA

##El conjunto de metacaracteres para expresiones regulares es el siguiente:
## \ ^ $ . [ ] { } | ( ) * + ?
#Estos caracteres, en una expresión regular, son interpretados en su significado especial y no como los caracteres que normalmente representan. Una búsqueda que implique alguno de estos caracteres obligará a "escaparlo" de la interpretación mediante \, como se hace para evitar la interpretación por el shell de los metacaracteres del shell. En una expresión regular, el caracter ? representa "un caracter cualquiera"; si escribimos \?, estamos representando el caracter ? tal cual, sin significado adicional.
