README TABLAS

Tabla definitiva de parlamentarios

LEGISLATURA 6 (6TH TERM)
mep7FFFF.txt

LEGISLATURA 7 (7TH TERM)
tablaEP2.txt
(Este documento es definitivo; antes de �l esta total_ordered; y en la carpeta de mep_process: meptotal-ordered).


