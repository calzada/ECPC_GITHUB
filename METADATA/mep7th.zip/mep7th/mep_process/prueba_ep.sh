#!/bin/bash
# prueba.sh
perl sandrfromhash_1.pl -table tablaep.txt e*.xml -regex
perl formatep.pl e*.xml