#Script: table-feeder_5.0
# This script opens a table-database, opens a listallnames list, identifies the items in a list and check whether these items exist in a document.
#Author: mc 
#Date: 29/01/2014

import sys,os,codecs,tkinter.filedialog

#Open and read your table_database (identifiers_only.txt). Identifiers_only.txt is an abridged document from mep7FFFF.txt, which only shows the latter's first column and uses no \p{Z}.

print("Choose your table-database. For example: identifiers_only.txt")
ASKEDtable=tkinter.filedialog.askopenfilename()

#En vez de mode='r', se puede poner mode='rb'
OPENEDtable_here=codecs.open(ASKEDtable, mode='r', encoding='utf-8')

contents_table=OPENEDtable_here.read()


#Open and read document for list (for example, listallnames_OJ_EN_FF/listallnames_DO_ES.txt)

print("Choose your document for list. For example: listallnames_OJ_EN_FF.txt")


ASKEDlistallnames=tkinter.filedialog.askopenfilename()

#En vez de mode='r', se puede poner mode='rb'
OPENEDlistallnames_F=codecs.open(ASKEDlistallnames, mode='r', encoding='utf-8')

EPsurnames_list=OPENEDlistallnames_F.readlines()
OPENEDtable_here.close()
OPENEDlistallnames_F.close()

#print(EPsurnames_list)

# Create a document to write on. This document is to be created in the a or ab mode because you are going to append all results. 

print("Creating a utf-8 text to write on")

#En vez de mode='a', se puede poner mode='ab'
CREATED_resultsfile=codecs.open('/Users/mc/Desktop/tablas/results_filename.txt', mode='a', encoding='utf-8')
     
#to check the file exists use os.path.exists("dir/file.txt")

#Chech whether items in list are NOT in table-database and print it in results_filename.txt documents. These are the names you need to include in the tale_database.

for listitem in EPsurnames_list:

    if listitem not in contents_table:

        #print(listitem)
        CREATED_resultsfile.write(listitem)
        CREATED_resultsfile.write("\n")

CREATED_resultsfile.close()

print("Well Done! Check your results_filename.txt")
