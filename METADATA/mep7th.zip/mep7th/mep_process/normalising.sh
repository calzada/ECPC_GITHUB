#!/bin/sh
#normalising.pl
#Este script sirve para que los nombres de los corpus no tengan variables
#autor: mc
#fecha: 23/01/2014

echo "Starting..."
echo "A..."

perl -pi -e 's/Adina-Ioana Vălean/Adina-Iona Vălean/g' *.xml

perl -pi -e 's/Agustín Díaz de Mera García Consuegra/Agustín Díaz De Mera García Consuegra/g' *.xml

perl -pi -e 's/Albert De/Albert Deß/g' *.xml
perl -pi -e 's/Albert Deßß/Albert Deß/g' *.xml
perl -pi -e 's/Albert De./Albert Deß/g' *.xml
perl -pi -e 's/Albert De.+(\p{Z}|<)/Albert Dess$1/g' *.xml

perl -pi -e 's/Alojz Peterle\./Alojz Peterle/g' *.xml

perl -pi -e 's/Andrea Češkov�/Andrea Češková/g' *.xml
perl -pi -e 's/Andrea Češkováá+/Andrea Češková/g' *.xml


perl -pi -e 's/Andres Perellò Rodríguez/Andres Perelló Rodríguez/g' *.xml

perl -pi -e 's/Anna Záborsk/Anna Záborská/g' *.xml
perl -pi -e 's/Anna Záborsk�/Anna Záborská/g' *.xml
perl -pi -e 's/Anna Záborskáá/Anna Záborská/g' *.xml
perl -pi -e 's/<name>Anna Záborská.<\/name>/<name>Anna Záborská<\/name>/g' *.xml


perl -pi -e 's/Andrea Češkov/Andrea Češková/g' *.xml
perl -pi -e 's/Andrea Češkováá/Andrea Češková/g' *.xml

perl -pi -e 's/Andrés Perello Rodríguez/Andrés Perelló Rodríguez/g' *.xml
perl -pi -e 's/Andres Perello Rodriguez/Andrés Perelló Rodríguez/g' *.xml

perl -pi -e 's/Antolin Sanchez Presedo/Antolín Sánchez Presedo/g' *.xml

perl -pi -e 's/António Fernando Correia de Campos/António Fernando Correia De Campos/g' *.xml


perl -pi -e 's/Arlene Mccarthy/Arlene McCarthy/g' *.xml


perl -pi -e 's/Arturs Krišjānis Kariņ�/Arturs Krišjānis Kariņš/g' *.xml
perl -pi -e 's/Arturs Krišjānis Kari/Arturs Krišjānis Kariņš/g' *.xml

perl -pi -e 's/Arturs Krišjānis Kariņšņš/Arturs Krišjānis Kariņš/g' *.xml


perl -pi -e 's/Bairbre de Brún/Bairbre De Brún/g' *.xml

echo "C..."

perl -pi -e 's/<name>Cãtãlin Sorin Ivan<\/name>/<name>Cătălin Sorin Ivan<\/name>/g' *.xml

perl -pi -e 's/Christa Kla/Christa Klaß/g' *.xml
perl -pi -e 's/Christa Kla�/Christa Klaß/g' *.xml
perl -pi -e 's/Christa Klaßß/Christa Klaß/g' *.xml
perl -pi -e 's/Christa Klaß/Christa Klass/g' *.xml
perl -pi -e 's/<name>Christa Klass.<\/name>/<name>Christa Klass<\/name>/g' *.xml


perl -pi -e 's/Cornelis de Jong/Cornelis De Jong/g' *.xml

perl -pi -e 's/Daciana Octavía Sârbu/Daciana Octavia Sârbu/g' *.xml

perl -pi -e 's/Daniël van der Stoep/Daniël Van Der Stoep/g' *.xml

echo "E..."

perl -pi -e 's/Edward Mcmillan-Scott/Edward McMillan-Scott/g' *.xml

perl -pi -e 's/Emilio Menéndez del Valle/Emilio Menéndez Del Valle/g' *.xml

perl -pi -e 's/Emma Mcclarkin/Emma McClarkin/g' *.xml

perl -pi -e 's/Enikõ Gyõri/Enikő Győri/g' *.xml
perl -pi -e 's/Győri, Enik/Enikő Győri/g' *.xml

perl -pi -e 's/Esther de Lange/Esther De Lange/g' *.xml

perl -pi -e 's/Evžen Tošenovsk/Evžen Tošenovský/g' *.xml
perl -pi -e 's/Evžen Tošenovskýý/Evžen Tošenovský/g' *.xml

perl -pi -e 's/Filiz Hakaeva Hyusmenov�/Filiz Hakaeva Hyusmenova/g' *.xml

echo "G..."

perl -pi -e 's/George Sabin Cuta/George Sabin Cutaş/g' *.xml
perl -pi -e 's/George Sabin Cuta�/George Sabin Cutaş/g' *.xml
perl -pi -e 's/George Sabin Cutaşş/George Sabin Cutaş/g' *.xml
perl -pi -e 's/George Sabin Cutaş�/George Sabin Cutaş/g' *.xml

perl -pi -e 's/Giancarlo Scott/Giancarlo Scottà/g' *.xml
perl -pi -e 's/Giancarlo Scottàà/Giancarlo Scottà/g' *.xml
perl -pi -e 's/Giancarlo Scottààà/Giancarlo Scottà/g' *.xml

perl -pi -e 's/Ingeborg Gräßle/Ingeborg Grässle/g' *.xml

perl -pi -e 's/Íñigo Méndez de Vigo/Íñigo Méndez De Vigo/g' *.xml

perl -pi -e 's/Ivaylo Kalfin/Ivailo Kalfin/g' *.xml



echo "J..."

perl -pi -e 's/Jaroslaw Kalinowski/Jarosław Kalinowski/g' *.xml

perl -pi -e 's/Jaroslaw Leszek Walesa/Jarosław Leszek WAŁĘSA/g' *.xml

perl -pi -e 's/<name>Jarosław Leszek WAŁĘSA<\/name>/<name>Jarosław Leszek Wałęsa<\/name>/g' *.xml

perl -pi -e 's/Jean Marie Cavada/Jean-Marie Cavada/g' *.xml

perl -pi -e 's/Johannes Cornelis van Baalen/Johannes Cornelis Van Baalen/g' *.xml

perl -pi -e 's/José Bov/José Bové/g' *.xml
perl -pi -e 's/José Bovéé/José Bové/g' *.xml

perl -pi -e 's/Jurgen Creutzmann/Jürgen Creutzmann/g' *.xml

perl -pi -e 's/Katarína Neveďalov�/Katarína Neveďalová/g' *.xml
perl -pi -e 's/Katarína Neveďalová�/Katarína Neveďalová/g' *.xml
perl -pi -e 's/<name>Katarína Neveďalov<\/name>/<name>Katarína Neveďalová<\/name>/g' *.xml


perl -pi -e 's/Kelam, Tunne/Tunne Kelam/g' *.xml

perl -pi -e 's/Krišjānis Kariņ�/Krišjānis Kariņš/g' *.xml


echo "L..."

perl -pi -e 's/Lambert van Nistelrooij/Lambert Van Nistelrooij/g' *.xml

perl -pi -e 's/Lidia Joanna Geringer de Oedenberg/Lidia Joanna Geringer de Oedenberg/g' *.xml

perl -pi -e 's/Laima Liucija Andrikien/Laima Liucija Andrikienė/g' *.xml
perl -pi -e 's/Laima Liucija Andrikiené/Laima Liucija Andrikienė/g' *.xml
perl -pi -e 's/Laima Liucija Andrikien�/Laima Liucija Andrikienė/g' *.xml
perl -pi -e 's/Laima Liucija Andrikienėė/Laima Liucija Andrikienė/g' *.xml
perl -pi -e 's/Laima Liucija Andrikienėé/Laima Liucija Andrikienė/g' *.xml
perl -pi -e 's/Laima Liucija Andrikienėéé/Laima Liucija Andrikienė/g' *.xml
perl -pi -e 's/Laima Liucija Andrikienėé/Laima Liucija Andrikienė/g' *.xml
perl -pi -e 's/<name>Laima Liucija Andrikienė�<\/name>/<name>Laima Liucija Andrikienė<\/name>/g' *.xml

perl -pi -e 's/<name>Lidia Joanna Geringer de Oedenberg<\/name>/<name>Lidia Joanna Geringer De Oedenberg<\/name>/g' *.xml

perl -pi -e 's/Linda Mcavan/Linda McAvan/g' *.xml

perl -pi -e 's/Lothar de Maizière/Lothar De Maizière/g' *.xml

perl -pi -e 's/Luigi de Magistris/Luigi De Magistris/g' *.xml

perl -pi -e 's/Luis de Grandes Pascual/Luis De Grandes Pascual/g' *.xml

perl -pi -e 's/<name>Luís de Grandes Pascual<\/name>/<name>Luis De Grandes Pascual<\/name>/g' *.xml

perl -pi -e 's/Luis Manuel Capoulas Santos/Luís Manuel Capoulas Santos/g' *.xml



perl -pi -e 's/Mairead Mcguinness/Mairead McGuinness/g' *.xml

perl -pi -e 's/Maria do Céu Patrão Neves/Maria Do Céu Patrão Neves/g' *.xml

perl -pi -e 's/<name>Michail Tremopoulo<\/name>/<name>Michail Tremopoulos<\/name>/g' *.xml

perl -pi -e 's/Monika Flašíková Beňov/Monika Flašíková Beňová/g' *.xml
perl -pi -e 's/Monika Flašíková Beňov�/Monika Flašíková Beňová/g' *.xml
perl -pi -e 's/Monika Flašíková Beňováá/Monika Flašíková Beňová/g' *.xml


perl -pi -e 's/Magdalena Alvarez/Magdalena Álvarez/g' *.xml

perl -pi -e 's/Maria da Graça Carvalho/Maria Da Graça Carvalho/g' *.xml

perl -pi -e 's/Miroslav Ouzk/Miroslav Ouzký/g' *.xml
perl -pi -e 's/Miroslav Ouzkýý+/Miroslav Ouzký/g' *.xml


perl -pi -e 's/Mojca Kleva/Mojca Kleva Kekuš/g' *.xml

perl -pi -e 's/Monika Smolkov�/Monika Smolková/g' *.xml
perl -pi -e 's/Monika Smolková�/Monika Smolková/g' *.xml

perl -pi -e 's/Monika Flašíková Beňová�/Monika Flašíková Beňová/g' *.xml

echo "O..."

perl -pi -e 's/Olga Sehnalov/Olga Sehnalová/g' *.xml
perl -pi -e 's/Olga Sehnalov�/Olga Sehnalová/g' *.xml
perl -pi -e 's/Olga Sehnalová�/Olga Sehnalová/g' *.xml
perl -pi -e 's/Olga Sehnalová�/Olga Sehnalová/g' *.xml
perl -pi -e 's/Olga Sehnalová��/Olga Sehnalová/g' *.xml
perl -pi -e 's/Olga Sehnalová���/Olga Sehnalová/g' *.xml
perl -pi -e 's/Olga Sehnalováá/Olga Sehnalová/g' *.xml
perl -pi -e 's/Olga Sehnalová�+/Olga Sehnalová/g' *.xml

perl -pi -e 's/Pat The Cope Gallagher/Pat the Cope Gallagher/g' *.xml

perl -pi -e 's/Peter Šťastn/Peter Šťastný/g' *.xml

perl -pi -e 's/<name>Peter Šťastnýý<\/name>/<name>Peter Šťastný<\/name>/g' *.xml

perl -pi -e 's/Peter van Dalen/Peter Van Dalen/g' *.xml

perl -pi -e 's/Philippe de Villiers/Philippe De Villiers/g' *.xml


perl -pi -e 's/Pilar del Castillo Vera/Pilar Del Castillo Vera/g' *.xml


perl -pi -e 's/Radvilė Morkūnaitė-Mikulėnien/Radvilė Morkūnaitė-Mikulėnienė/g' *.xml
perl -pi -e 's/Radvilė Morkūnaitė-Mikulėnien�/Radvilė Morkūnaitė-Mikulėnienė/g' *.xml
perl -pi -e 's/Radvilė Morkūnaitė-Mikulėnienė�/Radvilė Morkūnaitė-Mikulėnienė/g' *.xml
perl -pi -e 's/Radvilė Morkūnaitė-Mikulėnienėė/Radvilė 
Morkūnaitė-Mikulėnienė/g' *.xml
perl -pi -e 's/Radvilė Morkūnaitė-Mikulėnienė�/Radvilė 
Morkūnaitė-Mikulėnienė/g' *.xml
perl -pi -e 's/Radvilė Morkūnaitė-Mikulėnienė��/Radvilė 
Morkūnaitė-Mikulėnienė/g' *.xml
perl -pi -e 's/Radvilė Morkūnaitė-Mikulėnienėė/Radvilė 
Morkūnaitė-Mikulėnienė/g' *.xml


perl -pi -e 's/Rafał Kazimierz Trzaskowski/Rafał Trzaskowski/g' *.xml

perl -pi -e 's/Raffaele Baldassare/Raffaele Baldassarre/g' *.xml

perl -pi -e 's/Raimon Obiols i Germ/Raimon Obiols/g' *.xml

perl -pi -e 's/Ramon Tremosa i Balcells/Ramon Tremosa I Balcells/g' *.xml

perl -pi -e 's/<name>Ramón Tremosa i Balcells<\/name>/<name>Ramon Tremosa I Balcells<\/name>/g' *.xml

perl -pi -e 's/<name>Rares-Lucian Niculescu<\/name>/<name>Rareş-Lucian Niculescu<\/name>/g' *.xml

perl -pi -e 's/Raul Romeva i Rueda/Raül Romeva I Rueda/g' *.xml

perl -pi -e 's/Raül Romeva i Rueda/Raül Romeva I Rueda/g' *.xml

perl -pi -e 's/Romana Jordan/Romana Jordan Cizelj/g' *.xml

perl -pi -e 's/<name>Romana Jordan Cizelj Cizelj<\/name>/<name>Romana Jordan Cizelj<\/name>/g' *.xml

perl -pi -e 's/Róża Gräfin von Thun Und Hohenstein/Róża Gräfin Von Thun Und Hohenstein/g' *.xml
perl -pi -e 's/Róża, Gräfin von Thun Und Hohenstein/Róża Gräfin Von Thun Und Hohenstein/g' *.xml
perl -pi -e 's/Róża, Gräfin von Thun und Hohenstein/Róża Gräfin Von Thun Und Hohenstein/g' *.xml
perl -pi -e 's/Róża Gräfin von Thun und Hohenstein/Róża Gräfin Von Thun Und Hohenstein/g' *.xml


echo "S..."

perl -pi -e 's/Silvía Iranzo Gutiérrez/Silvia Iranzo Gutiérrez/g' *.xml

perl -pi -e 's/Sławomir Nitras/Sławomir Witold Nitras/g' *.xml

perl -pi -e 's/Sophia In .t Veld/Sophia in t Veld/g' *.xml

perl -pi -e 's/Sophia in .t Veld/Sophia In t Veld/g' *.xml


perl -pi -e 's/Sophie Briard Auconie/Sophie Auconie/g' *.xml

perl -pi -e 's/Takis Hatzigeorgiou/Takis Hadjigeorgiou/g' *.xml

echo "V..."

perl -pi -e 's/Vasilica Viorica Dãncil/Vasilica Viorica Dăncilă/g' *.xml
perl -pi -e 's/Vasilica Viorica Dăncil/Vasilica Viorica Dăncilă/g' *.xml
perl -pi -e 's/Vasilica Viorica Dăncilâ/Vasilica Viorica Dăncilă/g' *.xml
perl -pi -e 's/Vasilica Viorica Dăncil�/Vasilica Viorica Dăncilă/g' *.xml
perl -pi -e 's/Vasilica Viorica Dãncilăă/Vasilica Viorica Dăncilă/g' *.xml
perl -pi -e 's/Vasilica Viorica Dăncilăă/Vasilica Viorica Dăncilă/g' *.xml
perl -pi -e 's/Vasilica Viorica Dăncilăâ/Vasilica Viorica Dăncilă/g' *.xml
perl -pi -e 's/Vasilica Viorica Dăncilă�/Vasilica Viorica Dăncilă/g' *.xml

perl -pi -e 's/Veronica Lope Fontagné/Veronica Lope Fontagné/g' *.xml
perl -pi -e 's/Veronica Lope Fontagné�/Veronica Lope Fontagné/g' *.xml
perl -pi -e 's/Veronica Lope Fontagn/Veronica Lope Fontagné/g' *.xml
perl -pi -e 's/Veronica Lope Fontagn�/Veronica Lope Fontagné/g' *.xml
perl -pi -e 's/Verónica Lope Fontagné/Veronica Lope Fontagné/g' *.xml
perl -pi -e 's/Veronica Lope Fontagnéé/Veronica Lope Fontagné/g' *.xml

perl -pi -e 's/<name>Verónica Lope Fontagné.<\/name>/<name>Verónica Lope Fontagné<\/name>/g' *.xml

perl -pi -e 's/Veronica Lope Fontagné/Verónica Lope Fontagné/g' *.xml

perl -pi -e 's/Véronique Mathieu/Véronique Mathieu Houillon/g' *.xml

perl -pi -e 's/Wałęsa, Jarosław Leszek/Jarosław Leszek Wałęsa/g' *.xml

perl -pi -e 's/Wim van de Camp/Wim Van De Camp/g' *.xml

perl -pi -e 's/Winkler, Iuliu/Iuliu Winkler/g' *.xml

perl -pi -e 's/Vilija Blinkevičiūt�/Vilija Blinkevičiūtė/g' *.xml
perl -pi -e 's/VilijPa Blinkevičiūt�/Vilija Blinkevičiūtė/g' *.xml
perl -pi -e 's/Vilija Blinkevičiūt/Vilija Blinkevičiūtė/g' *.xml
perl -pi -e 's/Vilija Blinkevičiūtėė/Vilija Blinkevičiūtė/g' *.xml
perl -pi -e 's/Vilija Blinkevičiūtėė/Vilija Blinkevičiūtė/g' *.xml

perl -pi -e 's/Vilja Savisaar/Vilja Savisaar-Toomast/g' *.xml

perl -pi -e 's/Vilja Savisaar-Toomast-Toomast/Vilja Savisaar-Toomast/g' *.xml
perl -pi -e 's/Vilja Savisaar-Toomast-Toomast/Vilja Savisaar-Toomast/g' *.xml

perl -pi -e 's/Ville Itäl/Ville Itälä/g' *.xml
perl -pi -e 's/Ville Itäl�/Ville Itälä/g' *.xml
perl -pi -e 's/Ville Itälää/Ville Itälä/g' *.xml
perl -pi -e 's/Ville Itälää/Ville Itälä/g' *.xml

perl -pi -e 's/<name>Ville Itälä�<\/name>/<name>Ville Itälä<\/name>/g' *.xml

echo "Z..."

perl -pi -e 's/Zuzana Brzobohat�/Zuzana Brzobohatá/g' *.xml
perl -pi -e 's/Zuzana Brzobohatá��/Zuzana Brzobohatá/g' *.xml

echo "About to finish..."
perl -pi -e 's/Zuzana Roithov/Zuzana Roithová/g' *.xml
perl -pi -e 's/Zuzana Roithov�/Zuzana Roithová/g' *.xml
perl -pi -e 's/Zuzana Roithováá/Zuzana Roithová/g' *.xml

perl -pi -e 's/Zuzana Roithová�/Zuzana Roithová/g' *.xml

echo "The end!"
