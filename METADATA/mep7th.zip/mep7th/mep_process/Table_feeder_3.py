#Script: table-feeder_2.0
# This script opens a table-database, opens a listallnames list, identifies the items in a list and check whether these items exist in a document.
#Author: mc
#WARNING: THIS DOES NOT WORK PROPERLY. STILL UNDER CONSTRUCTION!
#Date: 29/01/2014

import sys,os,codecs,tkinter.filedialog

#Open and read your table_database (identifiers_only.txt). Remember not to include regex here (such as \p{Z}). It makes things more complicated.

print("Choose your table-database. For example: identifiers_only.txt")
ASKEDtable=tkinter.filedialog.askopenfilename()

OPENEDtable_here=codecs.open(ASKEDtable, mode='rb', encoding='utf-8')

contents_table=OPENEDtable_here.read()


#Open and read document for list (for example, listallnames_OJ_EN_FF)

print("Choose your document for list. For example: listallnames_OJ_EN_FF.txt")


ASKEDlistallnames=tkinter.filedialog.askopenfilename()

OPENEDlistallnames_F=codecs.open(ASKEDlistallnames, mode='rb', encoding='utf-8')

EPsurnames_list=OPENEDlistallnames_F.readlines()

#print(EPsurnames_list)

#Create a document to write on

print("Creating a utf-8 text to write on")
      
CREATED_resultsfile=codecs.open('results_filename.txt', mode='w', encoding='utf-8')

# to check the file exists use os.path.exists("dir/file.txt")

#Chech whether items in list are NOT in table-database and print it. These are the names you need to include in the tale_database.

new_list=[]

for listitem in EPsurnames_list:

    if listitem not in contents_table:

        print(listitem)


#for item in final_results:

#    CREATED_resultsfile.write("%s\n" % item)

OPENEDtable_here.close()
OPENEDlistallnames_F.close()
CREATED_resultsfile.close()
