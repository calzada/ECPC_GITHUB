#Script: text_to_list_1.0
# This script takes lines from a txt and uses them to create a list.I can use it to combine it with XXX
#Date: 29/01/2014


import os,codecs,tkinter.filedialog

ASKEDlistallnames=tkinter.filedialog.askopenfilename()

OPENEDlistallnames_F=codecs.open(ASKEDlistallnames, mode='rb', encoding='utf-8')

EPsurnames_list=OPENEDlistallnames_F.readlines()

